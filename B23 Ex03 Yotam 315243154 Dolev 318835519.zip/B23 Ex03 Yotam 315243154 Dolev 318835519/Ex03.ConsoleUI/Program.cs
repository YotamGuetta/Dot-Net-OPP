﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex03_UI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            UI v_ui = new UI();
            v_ui.Menu();
        }
    }
}
