﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLogics
{
    public class GameResultEnum
    {
        public enum eGameResult
        { 
            Player1,
            Player2,
            Draw,
            NoWinner
        }
    }
}
