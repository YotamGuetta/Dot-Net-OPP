﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLogics
{
    public class ActivePlayerEnum
    {
        public enum eGameType
        {
            HumanVsAi = 1,
            HumanVsHuman = 2
        }
    }
}
